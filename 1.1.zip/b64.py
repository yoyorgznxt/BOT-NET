import base64

with open('uuid_get.py', 'rb') as f:
    content = f.read()
    b64_content = base64.b64encode(content).decode('utf-8')
    with open("b64.txt", "w") as f:
                f.write(b64_content)